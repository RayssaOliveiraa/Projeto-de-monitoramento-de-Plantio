# Projeto de Monitoramento de Plantio

## Sobre
Este projeto consiste em uma aplicação desenvolvida para capturar os parâmetros dos sensores de umidade, temperatura e pH do solo.

### Detalhes Técnicos
- Desenvolvido utilizando o framework Flutter baseado em linguagem Dart.
- Ambiente de desenvolvimento: Sistema operacional Windows.

## Instalação
1. Clone o repositório: `
2. Acesse a pasta do projeto: `
3. Instale as dependências: 
4. Execute o projeto:

## Utilização da aplicação

